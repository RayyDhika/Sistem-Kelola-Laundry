<div class="modal fade" id="modalEdit<?php echo e($p->id); ?>" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content shadow-lg p-3">

            <div class="modal-header border-0 pb-0">

                <h5 class="modal-title fw-bold">
                    <i></i>
                    EDIT DATA PAKET
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>

            </div>

            <form action="<?php echo e(route('paket.update', $p->id)); ?>" method="POST">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="modal-body">

                    <!-- OUTLET -->
                    <div class="mb-3">

                        <label class="form-label">
                            Pilih Outlet
                        </label>

                        <select name="id_outlet" class="form-select" required>

                            <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($outlet->id); ?>" <?php echo e($p->id_outlet == $outlet->id ? 'selected' : ''); ?>>

                                    <?php echo e($outlet->nm_outlet); ?>


                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>

                    <!-- JENIS -->
                    <div class="mb-3">

                        <label class="form-label">
                            Jenis Paket
                        </label>

                        <select name="jenis" class="form-select" required>

                            <option value="kiloan" <?php echo e($p->jenis == 'kiloan' ? 'selected' : ''); ?>>
                                Kiloan
                            </option>

                            <option value="satuan" <?php echo e($p->jenis == 'satuan' ? 'selected' : ''); ?>>
                                Satuan
                            </option>

                        </select>

                    </div>

                    <!-- NAMA -->
                    <div class="mb-3">

                        <label class="form-label">
                            Nama Paket
                        </label>

                        <input type="text" name="nm_paket" class="form-control" value="<?php echo e($p->nm_paket); ?>" required>

                    </div>

                    <!-- HARGA -->
                    <div class="mb-3">

                        <label class="form-label">
                            Harga
                        </label>

                        <input type="number" name="harga" class="form-control" value="<?php echo e($p->harga); ?>" required>

                    </div>

                </div>

                <div class="modal-footer border-0">

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">

                        BATAL

                    </button>

                    <button type="submit" class="btn btn-primary">

                        SIMPAN

                    </button>

                </div>

            </form>

        </div>

    </div>

</div><?php /**PATH C:\laravel\BubbleBliss\resources\views/paket/edit.blade.php ENDPATH**/ ?>