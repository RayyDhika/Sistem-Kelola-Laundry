

<?php $__env->startSection('title', 'Registrasi Pelanggan - BubbleBliss'); ?>
<?php $__env->startSection('page_title', 'REGISTRASI PELANGGAN'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pelanggan.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-custom">
        <div class="table-header">
            <h4 class="table-title">DATA PELANGGAN</h4>
            <div class="d-flex gap-2">
                <div class="search-box position-relative">
                    <i class="fa fa-search position-absolute" style="left:12px; top:13px; color: #3b82f6;"></i>
                    <input type="text" id="searchInput" class="form-control" placeholder="Cari Pelanggan...">
                </div>
                <button class="btn-add" data-bs-toggle="modal" data-bs-target="#modalTambah">
                    <i class="fa fa-plus me-2"></i> TAMBAH PELANGGAN
                </button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-custom" id="pelangganTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>No Tlp</th>
                        <th>L/P</th>
                        <th>Outlet</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($no + 1); ?></td>
                            <td class="nama-pelanggan"><?php echo e($p->nm_pelanggan); ?></td>
                            <td class="text-center"><?php echo e($p->no_telp); ?></td>
                            <td class="text-center">
                                <?php if($p->jenis_kelamin == 'L'): ?>
                                    <span class="badge bg-primary"><?php echo e($p->jenis_kelamin); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-pink text-white" style="background:#ff69b4;"><?php echo e($p->jenis_kelamin); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($p->outlet->nm_outlet ?? '-'); ?></td>
                            <td><?php echo e($p->alamat); ?></td>
                            <td class="text-center">
                                <button class="btn btn-primary btn-sm btn-edit" data-id="<?php echo e($p->id); ?>"
                                    data-nama="<?php echo e($p->nm_pelanggan); ?>" data-telp="<?php echo e($p->no_telp); ?>"
                                    data-jk="<?php echo e($p->jenis_kelamin); ?>" data-alamat="<?php echo e($p->alamat); ?>"
                                    data-outlet="<?php echo e($p->id_outlet); ?>">
                                    <i class="fa fa-edit"></i>
                                </button>
                                <button class="btn btn-danger btn-sm" onclick="konfirmasiHapus(<?php echo e($p->id); ?>)">
                                    <i class="fa fa-trash"></i>
                                </button>
                                <form id="form-hapus-<?php echo e($p->id); ?>" action="<?php echo e(route('pelanggan.destroy', $p->id)); ?>"
                                    method="POST" style="display:none;">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-3">Belum ada data pelanggan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="modalTambah" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content p-4">
                <h5 class="text-primary fw-bold mb-4">TAMBAH PELANGGAN</h5>
                <form action="<?php echo e(route('pelanggan.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="section-box">
                                <label class="form-label-blue">Nama Pelanggan</label>
                                <input type="text" name="nm_pelanggan" class="form-control" placeholder="Masukan Nama Pelanggan..." required>
                            </div>
                            <div class="section-box">
                                <label class="form-label-blue">No Telepon</label>
                                <input type="text" name="no_telp" id="no_telp" class="form-control" placeholder="Masukan Nomor Telepon" maxlength="15" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="section-box">
                                <label class="form-label-blue mb-2">Jenis Kelamin</label>
                                <div class="radio-box">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="jenis_kelamin" value="L" required>
                                        <label class="form-check-label">Laki-Laki</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="jenis_kelamin" value="P">
                                        <label class="form-check-label">Perempuan</label>
                                    </div>
                                </div>
                            </div>
                            <div class="section-box">
                                <label class="form-label-blue">Alamat</label>
                                <textarea name="alamat" class="form-control" rows="4" placeholder="Masukan Alamat Lengkap..." required></textarea>
                            </div>
                            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'owner'): ?>
                                <div class="section-box">
                                    <label class="form-label-blue">Outlet</label>
                                    <select name="id_outlet" class="form-control" required>
                                        <option value="">Pilih Outlet</option>
                                        <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($outlet->id); ?>"><?php echo e($outlet->nm_outlet); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-3 mt-4">
                        <button type="button" class="btn-batal" data-bs-dismiss="modal">BATAL</button>
                        <button type="submit" class="btn-simpan">SIMPAN</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('pelanggan.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pelanggan.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laravel\BubbleBliss\resources\views/pelanggan/create.blade.php ENDPATH**/ ?>