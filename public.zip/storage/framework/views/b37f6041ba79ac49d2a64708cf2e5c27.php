<!-- MODAL DETAIL & EDIT -->
    <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="modal fade" id="modalDetail<?php echo e($t->id); ?>" tabindex="-1">

            <div class="modal-dialog modal-dialog-centered">

                <div class="modal-content p-4">

                    <h5 class="text-primary mb-3">
                        Detail Transaksi
                    </h5>

                    <div class="mb-2">
                        <b>Pelanggan:</b><br>

                        <span class="detail-value">
                            <?php echo e($t->pelanggan->nm_pelanggan); ?>

                        </span>

                    </div>

                    <div class="mb-2">
                        <b>Invoice:</b><br>

                        <span class="detail-value">
                            <?php echo e($t->kode_invoice); ?>

                        </span>
                    </div>

                    <div class="mb-2">
                        <b>Status:</b><br>

                        <?php if($t->status == 'proses'): ?>

                            <span class="badge bg-info text-white">
                                Proses
                            </span>

                        <?php else: ?>

                            <span class="badge bg-success text-white">
                                Selesai
                            </span>

                        <?php endif; ?>
                    </div>

                    <div class="mb-2">
                        <b>Status Pembayaran:</b><br>

                        <?php if($t->status_bayar == 'dibayar'): ?>

                            <span class="badge bg-success">
                                Lunas
                            </span>

                        <?php else: ?>

                            <span class="badge bg-danger">
                                Belum Lunas
                            </span>

                        <?php endif; ?>
                    </div>

                    <div class="mb-2">
                        <b>Tanggal Masuk:</b><br>
                        <span class="detail-value">
                            <?php echo e(\Carbon\Carbon::parse($t->tgl_masuk)->format('d M Y')); ?>

                        </span>
                    </div>

                    <div class="mb-2">
                        <b>Estimasi Selesai:</b><br>
                        <span class="detail-value">
                            <?php echo e(\Carbon\Carbon::parse($t->batas_waktu)->format('d M Y')); ?>

                        </span>
                    </div>

                    <div class="mb-2">
                        <b>Paket Laundry:</b><br>

                        <?php $__currentLoopData = $t->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="border rounded-3 p-2 mb-2" style="background:#f8fbff;">

                                <span class="detail-value">
                                    <?php echo e($detail->paket->nm_paket ?? '-'); ?>

                                </span>

                                <br>

                                <small style="color:#6b8bd6;">
                                    <?php echo e($detail->qty); ?> x
                                    Rp <?php echo e(number_format($detail->paket->harga ?? 0, 0, ',', '.')); ?>

                                </small>

                                <br>

                                <b style="font-size:13px;">
                                    Subtotal :
                                    Rp <?php echo e(number_format(($detail->qty * ($detail->paket->harga ?? 0)), 0, ',', '.')); ?>

                                </b>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="mb-2">
                        <b>Total Harga:</b><br>

                        <span class="detail-value">
                            Rp <?php echo e(number_format($t->total_harga ?? 0, 0, ',', '.')); ?>

                        </span>
                    </div>

                    <?php if($t->tgl_bayar): ?>
                        <div class="mb-2">
                            <b>Tanggal Bayar:</b><br>
                            <span class="detail-value">
                                <?php echo e(\Carbon\Carbon::parse($t->tgl_bayar)->format('d M Y')); ?>

                            </span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalEdit<?php echo e($t->id); ?>" tabindex="-1">

            <div class="modal-dialog modal-dialog-centered" style="max-width:500px;">

                <div class="modal-content" style="
                                                    border-radius:18px;
                                                    padding:10px 14px;
                                                 ">

                    <div class="modal-header border-0 pb-1">

                        <h5 class="fw-bold text-primary mb-0" style="font-size:16px;">

                            EDIT TRANSAKSI : <?php echo e($t->kode_invoice); ?>


                        </h5>

                        <button type="button" class="btn-close" data-bs-dismiss="modal">
                        </button>

                    </div>

                    <form action="<?php echo e(route('transaksi.update', $t->id)); ?>" method="POST">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="modal-body pt-1 pb-2">

                            <div class="mb-2">

                                <label class="form-label text-primary fw-bold mb-1" style="font-size:14px;">

                                    Status Progres

                                </label>

                                <select name="status" class="form-select" style="height:40px; font-size:14px;">

                                    <option value="proses" <?php echo e($t->status == 'proses' ? 'selected' : ''); ?>>
                                        Proses
                                    </option>

                                    <option value="selesai" <?php echo e($t->status == 'selesai' ? 'selected' : ''); ?>>
                                        Selesai
                                    </option>

                                </select>

                            </div>

                            <div class="mb-2">

                                <label class="form-label text-primary fw-bold mb-1" style="font-size:14px;">

                                    Status Pembayaran

                                </label>

                                <select name="status_bayar" class="form-select" style="height:40px; font-size:14px;">

                                    <option value="dibayar" <?php echo e($t->status_bayar == 'dibayar' ? 'selected' : ''); ?>>
                                        Lunas
                                    </option>

                                    <option value="belum" <?php echo e($t->status_bayar == 'belum' ? 'selected' : ''); ?>>
                                        Belum Lunas
                                    </option>

                                </select>

                            </div>

                        </div>

                        <div class="modal-footer border-0 pt-1">

                            <button type="button" class="btn btn-outline-secondary btn-sm px-3" data-bs-dismiss="modal">

                                Batal

                            </button>

                            <button type="submit" class="btn btn-primary btn-sm px-3" style="background:#0649ca">

                                Simpan

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laravel\BubbleBliss\resources\views/transaksi/edit.blade.php ENDPATH**/ ?>