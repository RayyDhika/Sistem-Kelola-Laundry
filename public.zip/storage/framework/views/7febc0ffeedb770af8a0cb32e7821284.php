

<?php $__env->startSection('title', 'Data Pengguna - BubbleBliss'); ?>
<?php $__env->startSection('page_title', 'DATA PENGGUNA'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/user.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="stat-card bg-blue-1">
                <div>
                    <small>JUMLAH PENGGUNA</small>
                    <h3><?php echo e($users->count()); ?></h3>
                </div>
                <i class="fa fa-user fs-1 opacity-50"></i>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card bg-blue-2">
                <div>
                    <small>JUMLAH OUTLET</small>
                    <h3><?php echo e($outlets->count()); ?></h3>
                </div>
                <i class="fa fa-store fs-1 opacity-50"></i>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card bg-blue-3">
                <div>
                    <small>JUMLAH PAKET</small>
                    <h3><?php echo e($pakets->count()); ?></h3>
                </div>
                <i class="fa fa-box fs-1 opacity-50"></i>
            </div>
        </div>
    </div>

    <div class="card-custom">
        <div class="table-header">
            <h4 class="table-title">DATA PENGGUNA</h4>
            <div class="d-flex align-items-center gap-3">
                <div class="search-box position-relative">
                    <i class="fa fa-search position-absolute" style="left:12px; top:13px; color:#3b82f6;"></i>
                    <input type="text" id="searchUser" class="form-control" placeholder="Cari Pengguna..."
                        style="font-family: Arial, Helvetica, sans-serif; padding-left:35px; width:260px; height:43px; font-size:16px; border:1.3px solid #3577f3; border-radius:10px; box-shadow:none;">
                </div>

                <button class="btn-add" data-bs-toggle="modal" data-bs-target="#modalTambahUser">
                    <i class="fa fa-plus me-2"></i> TAMBAH PENGGUNA
                </button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table align-middle table-user-custom" id="userTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>L/P</th>
                        <th>Email</th>
                        <th>Outlet</th>
                        <th>Password</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="id-user text-center">
                                P00<?php echo e($u->id); ?>

                            </td>

                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <div class="avatar-user">
                                        <?php echo e(strtoupper(substr($u->name, 0, 1))); ?>

                                    </div>
                                    <div class="text-start">
                                        <div class="nama-user">
                                            <?php echo e($u->name); ?>

                                        </div>
                                        <small style="color: #7aa6ff; font-size: 12px;">
                                            <?php echo e($u->telepon ?? '-'); ?>

                                        </small>
                                    </div>
                                </div>
                            </td>

                            <td class="text-center">
                                <?php if($u->jk == 'Laki - Laki' || $u->jk == 'L'): ?>
                                    <span class="badge bg-primary">L</span>
                                <?php else: ?>
                                    <span class="badge text-white" style="background:#ff69b4;">P</span>
                                <?php endif; ?>
                            </td>

                            <td class="email-user">
                                <?php echo e($u->email); ?>

                            </td>

                            <td class="text-center">
                                <?php echo e($u->outlet->nm_outlet ?? '-'); ?>

                            </td>

                            <td class="text-center" style="letter-spacing: 2px;">
                                ••••••••
                            </td>

                            <td class="text-center">
                                <span class="badge rounded-pill px-3 py-2 
                            <?php if($u->role == 'admin'): ?> bg-primary text-white
                            <?php elseif($u->role == 'kasir'): ?> bg-success text-white
                            <?php else: ?> bg-warning text-dark <?php endif; ?>">
                                    <?php echo e(ucfirst($u->role)); ?>

                                </span>
                            </td>

                            <td class="text-center">
                                <div class="d-flex justify-content-center gap-2">

                                    <button class="btn btn-sm btn-primary text-white" data-bs-toggle="modal"
                                        data-bs-target="#modalEditUser<?php echo e($u->id); ?>">
                                        <i class="fa fa-edit"></i>
                                    </button>

                                    <button class="btn btn-sm btn-danger" onclick="konfirmasiHapus(<?php echo e($u->id); ?>)">
                                        <i class="fa fa-trash"></i>
                                    </button>

                                    <form id="form-hapus-<?php echo e($u->id); ?>" action="<?php echo e(route('user.destroy', $u->id)); ?>"
                                        method="POST" style="display:none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>

                                </div>
                            </td>
                        </tr>

                        <?php echo $__env->make('user.edit', ['u' => $u, 'outlets' => $outlets], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-3">Belum ada data pengguna</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="modalTambahUser" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 p-3">
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-bold text-primary">Tambah Pengguna</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="<?php echo e(route('user.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body" style="font-family: Arial, Helvetica, sans-serif">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0 ps-3">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-secondary small fw-bold">Nama Lengkap</label>
                                <input type="text" name="name" class="form-control" placeholder="Masukan Nama Lengkap"
                                    value="<?php echo e(old('name')); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label text-secondary small fw-bold">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Masukan Email"
                                    value="<?php echo e(old('email')); ?>" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="form-label text-secondary small fw-bold">Nomor Telepon</label>
                                <input type="text" name="telepon" id="telepon" class="form-control"
                                    placeholder="Masukan Nomor Telepon" value="<?php echo e(old('telepon')); ?>" maxlength="15">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label text-secondary small fw-bold">Jenis Kelamin</label>
                                <select name="jk" class="form-select" required>
                                    <option value="Laki - Laki" <?php echo e(old('jk') == 'Laki - Laki' ? 'selected' : ''); ?>>Laki - Laki</option>
                                    <option value="Perempuan" <?php echo e(old('jk') == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label text-secondary small fw-bold">Password</label>
                                <div class="input-group">
                                    <input type="password" name="password" id="passwordInput" class="form-control"
                                        placeholder="Masukan Password" required>
                                    <span class="input-group-text" onclick="toggleInputPassword()" style="cursor:pointer;">
                                        <i class="fa fa-eye" id="eyeIcon"></i>
                                    </span>
                                </div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label text-secondary small fw-bold">Outlet</label>
                                <?php if(auth()->user()->role == 'admin'): ?>
                                    <select name="id_outlet" class="form-select" required>
                                        <option value="">Pilih Outlet</option>
                                        <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($outlet->id); ?>" <?php echo e(old('id_outlet') == $outlet->id ? 'selected' : ''); ?>><?php echo e($outlet->nm_outlet); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php else: ?>
                                    <input type="hidden" name="id_outlet" value="<?php echo e(auth()->user()->id_outlet); ?>">
                                    <input type="text" class="form-control"
                                        value="<?php echo e(auth()->user()->outlet->nm_outlet ?? '-'); ?>" readonly>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label text-secondary small fw-bold">Role</label>
                                <select name="role" class="form-select" required>
                                    <option value="kasir" <?php echo e(old('role') == 'kasir' ? 'selected' : ''); ?>>Kasir</option>
                                    <option value="owner" <?php echo e(old('role') == 'owner' ? 'selected' : ''); ?>>Owner</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary px-4">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('user.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if($errors->any()): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var modalTambah = new bootstrap.Modal(document.getElementById('modalTambahUser'));
                modalTambah.show();
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laravel\BubbleBliss\resources\views/user/index.blade.php ENDPATH**/ ?>