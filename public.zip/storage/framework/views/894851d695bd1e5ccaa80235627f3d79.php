<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Outlet - BubbleBliss</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Hammersmith+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/outlet.css')); ?>">
</head>

<body>

    <div class="topbar">

        <div class="logo-header">
            <img src="<?php echo e(asset('images/logoputih.png')); ?>" width="45">
            <span style="font-size:26px">BubbleBliss</span>
        </div>

        <div class="header-right px-4">

            <div>
                <h4 class="mb-0" style="color: #0650d1; font-size: 28px;">
                    DATA OUTLET
                </h4>

                <small style="color: #5691f6; font-size: 17px;">
                    Kelola Data Outlet Laundry Anda
                </small>
            </div>
            <?php echo $__env->make('partials.profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

    </div>
    </div>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <div class="row g-3 mb-4">

            <div class="col-md-4">
                <div class="stat-card bg-blue-1">
                    <div>
                        <small>JUMLAH PENGGUNA</small>
                        <h3><?php echo e($users->count()); ?></h3>
                    </div>

                    <i class="fa fa-user fs-1 opacity-50"></i>
                </div>
            </div>

            <div class="col-md-4">
                <div class="stat-card bg-blue-2">
                    <div>
                        <small>JUMLAH OUTLET</small>
                        <h3><?php echo e($outlets->count()); ?></h3>
                    </div>

                    <i class="fa fa-store fs-1 opacity-50"></i>
                </div>
            </div>

            <div class="col-md-4">
                <div class="stat-card bg-blue-3">
                    <div>
                        <small>JUMLAH PAKET</small>
                        <h3><?php echo e($pakets->count()); ?></h3>
                    </div>

                    <i class="fa fa-box fs-1 opacity-50"></i>
                </div>
            </div>

        </div>

        <div class="card-custom">

            <div class="table-header">

                <h4 class="table-title">
                    DATA OUTLET
                </h4>

                <?php if(auth()->user()->role == 'admin'): ?>

                    <button class="btn-add" data-bs-toggle="modal" data-bs-target="#modalTambah">

                        <i class="fa fa-plus me-2"></i>
                        TAMBAH OUTLET

                    </button>

                <?php endif; ?>

            </div>

            <div class="table-responsive">

                <table class="table table-custom">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Outlet</th>
                            <th>Alamat</th>
                            <th>No Tlp</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>

                                <td>UO0<?php echo e($o->id); ?></td>

                                <td><?php echo e($o->nm_outlet); ?></td>

                                <td><?php echo e($o->alamat); ?></td>

                                <td><?php echo e($o->no_telp); ?></td>

                                <td>
                                    <div class="d-flex justify-content-center gap-2">

                                        <button class="btn btn-sm btn-primary text-white" data-bs-toggle="modal"
                                            data-bs-target="#modalEdit<?php echo e($o->id); ?>">
                                            <i class="fa fa-edit"></i>
                                        </button>

                                        <button class="btn btn-sm btn-danger" onclick="konfirmasiHapus(<?php echo e($o->id); ?>)">
                                            <i class="fa fa-trash"></i>
                                        </button>

                                        <form id="form-hapus-<?php echo e($o->id); ?>" action="<?php echo e(route('outlet.destroy', $o->id)); ?>"
                                            method="POST" style="display:none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>

                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td colspan="5" class="text-center py-3">
                                    Belum ada data outlet
                                </td>
                            </tr>

                        <?php endif; ?>


                </table>

            </div>

        </div>

    </div>

    <!-- MODAL TAMBAH -->
    <div class="modal fade" id="modalTambah" tabindex="-1" aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content">

                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">TAMBAH OUTLET</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <hr class="mx-2" style="color: #aec6eb">

                <form action="<?php echo e(route('outlet.store')); ?>" method="POST">

                    <?php echo csrf_field(); ?>

                    <div class="modal-body px-4">

                        <div class="mb-3 row">

                            <label class="col-sm-3 form-label-blue mt-2">
                                Nama Outlet :
                            </label>

                            <div class="col-sm-9">
                                <input type="text" name="nm_outlet" class="form-control"
                                    placeholder="Masukan Nama Outlet" required>
                            </div>

                        </div>

                        <div class="mb-3 row">

                            <label class="col-sm-3 form-label-blue mt-2">
                                No TLP :
                            </label>

                            <div class="col-sm-9 d-flex gap-2">

                                <!-- nomor -->
                                <input type="text" name="no_telp" class="form-control" id="telepon"
                                    placeholder="Masukan Nomor Telepon" required>
                            </div>

                        </div>

                        <div class="mb-3 row">

                            <label class="col-sm-3 form-label-blue mt-2">
                                Alamat :
                            </label>

                            <div class="col-sm-9">
                                <textarea name="alamat" class="form-control" rows="3"
                                    placeholder="Masukan Alamat Lengkap" required></textarea>
                            </div>

                        </div>

                        <input type="hidden" name="owner" value="Admin">

                    </div>

                    <div class="modal-footer border-0">

                        <button type="button" class="btn-batal" data-bs-dismiss="modal">
                            BATAL
                        </button>

                        <button type="submit" class="btn-simpan">
                            TAMBAH
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

    <?php echo $__env->make('outlet.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('outlet.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH C:\laravel\BubbleBliss\resources\views/outlet/index.blade.php ENDPATH**/ ?>