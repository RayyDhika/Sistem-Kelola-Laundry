<div class="modal fade" id="modalEditUser<?php echo e($u->id); ?>" tabindex="-1">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content border-0 rounded-4">

            <!-- HEADER -->
            <div class="modal-header">

                <h5 class="modal-title fw-bold text-primary">
                    Edit Pengguna
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>

            </div>

            <!-- FORM -->
            <form action="<?php echo e(route('user.update', $u->id)); ?>" method="POST">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="modal-body">

                    <div class="row">

                        <!-- NAMA -->
                        <div class="col-md-6 mb-3" style="font-family: Arial, Helvetica, sans-serif">

                            <label class="form-label">
                                Nama Lengkap
                            </label>

                            <input type="text" name="name" class="form-control" value="<?php echo e($u->name); ?>" required>

                        </div>

                        <!-- EMAIL -->
                        <div class="col-md-6 mb-3" style="font-family: Arial, Helvetica, sans-serif">

                            <label class="form-label">
                                Email
                            </label>

                            <input type="email" name="email" class="form-control" value="<?php echo e($u->email); ?>" required>

                        </div>

                        <!-- TELEPON -->
                        <div class="col-md-12 mb-3" style="font-family: Arial, Helvetica, sans-serif">

                            <label class="form-label">
                                Nomor Telepon
                            </label>

                            <div class="d-flex gap-2">
                                <!-- nomor -->
                                <input type="text" name="telepon" id="telepon_edit<?php echo e($u->id); ?>" class="form-control"
                                    value="<?php echo e($u->telepon); ?>" placeholder="Masukan Nomor Telepon">

                            </div>

                        </div>

                        <!-- JK -->
                        <div class="col-md-6 mb-3" style="font-family: Arial, Helvetica, sans-serif">

                            <label class="form-label">
                                Jenis Kelamin
                            </label>

                            <select name="jk" class="form-select">

                                <option value="Laki - Laki" <?php echo e($u->jk == 'Laki - Laki' ? 'selected' : ''); ?>>
                                    Laki - Laki
                                </option>

                                <option value="Perempuan" <?php echo e($u->jk == 'Perempuan' ? 'selected' : ''); ?>>
                                    Perempuan
                                </option>

                            </select>

                        </div>

                        <!-- PASSWORD -->
                        <div class="col-md-6 mb-3" style="font-family: Arial, Helvetica, sans-serif">

                            <label class="form-label">
                                Password Baru
                            </label>

                            <div class="input-group">

                                <input type="password" name="password" id="passwordEdit<?php echo e($u->id); ?>"
                                    class="form-control" placeholder="Kosongkan jika tidak diubah">

                                <span class="input-group-text" onclick="toggleEditPassword(<?php echo e($u->id); ?>)"
                                    style="cursor:pointer;">

                                    <i class="fa fa-eye" id="eyeEdit<?php echo e($u->id); ?>"></i>

                                </span>

                            </div>

                        </div>

                        <!-- OUTLET -->
                        <div class="col-md-6 mb-3" style="font-family: Arial, Helvetica, sans-serif">

                            <label class="form-label">Outlet</label>

                            <?php if($u->role == 'admin'): ?>

                                <input type="text" class="form-control" value="-" disabled>

                                <input type="hidden" name="id_outlet" value="">

                            <?php else: ?>

                                <select name="id_outlet" class="form-select">

                                    <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($outlet->id); ?>" <?php echo e($u->id_outlet == $outlet->id ? 'selected' : ''); ?>>

                                            <?php echo e($outlet->nm_outlet); ?>


                                        </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                            <?php endif; ?>

                        </div>

                        <!-- ROLE -->
                        <div class="col-md-6 mb-3" style="font-family: Arial, Helvetica, sans-serif">

                            <label class="form-label">Role</label>

                            <?php if($u->role == 'admin'): ?>

                                <input type="text" class="form-control" value="Admin" disabled>

                            <?php else: ?>

                                <select name="role" class="form-select">

                                    <option value="kasir" <?php echo e($u->role == 'kasir' ? 'selected' : ''); ?>>
                                        Kasir
                                    </option>

                                    <option value="owner" <?php echo e($u->role == 'owner' ? 'selected' : ''); ?>>
                                        Owner
                                    </option>

                                </select>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

                <!-- FOOTER -->
                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">

                        Batal

                    </button>

                    <button type="submit" class="btn btn-primary">

                        Simpan

                    </button>

                </div>

            </form>

        </div>

    </div>

</div><?php /**PATH C:\laravel\BubbleBliss\resources\views/user/edit.blade.php ENDPATH**/ ?>