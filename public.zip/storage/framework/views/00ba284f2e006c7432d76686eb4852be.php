<div class="sidebar text-white">

    <?php if(auth()->user()->role == 'owner'): ?>

        <div class="menu-title-main">MENU UTAMA</div>

        <a href="<?php echo e(route('owner.dashboard')); ?>" 
            class="menu-link <?php echo e(request()->routeIs('owner.dashboard') ? 'active-menu' : ''); ?>">
            <i class="fa fa-file-text"></i> Laporan
        </a>

    <?php else: ?>

        <div class="menu-title-main">MENU UTAMA</div>

        
        <?php if(auth()->user()->role == 'admin'): ?>
            <a href="<?php echo e(route('dashboard')); ?>" class="menu-link <?php echo e(request()->routeIs('dashboard') ? 'active-menu' : ''); ?>">
                <i class="fa fa-home"></i> Beranda
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('kasir.dashboard')); ?>"
                class="menu-link <?php echo e(request()->routeIs('kasir.dashboard') ? 'active-menu' : ''); ?>">
                <i class="fa fa-home"></i> Beranda
            </a>
        <?php endif; ?>

        <div class="menu-title-main">TRANSAKSI</div>

        
        <?php if(auth()->user()->role == 'admin'): ?>
            <a href="<?php echo e(route('pelanggan.index')); ?>"
                class="menu-link <?php echo e(request()->routeIs('pelanggan.*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-user-plus"></i> Register Pelanggan
            </a>

            <a href="<?php echo e(route('transaksi.index')); ?>"
                class="menu-link <?php echo e(request()->routeIs('transaksi.*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-cart-plus"></i> Entri Transaksi
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('kasir.pelanggan')); ?>"
                class="menu-link <?php echo e(request()->routeIs('kasir.pelanggan*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-user-plus"></i> Register Pelanggan
            </a>

            <a href="<?php echo e(route('kasir.transaksi')); ?>"
                class="menu-link <?php echo e(request()->routeIs('kasir.transaksi*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-cart-plus"></i> Entri Transaksi
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->role == 'admin'): ?>
            <div class="menu-title-main">DATA</div>

            <a href="<?php echo e(route('user.index')); ?>" class="menu-link <?php echo e(request()->routeIs('user.*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-user"></i> Data Pengguna
            </a>

            <a href="<?php echo e(route('outlet.index')); ?>" class="menu-link <?php echo e(request()->routeIs('outlet.*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-shop"></i> Data Outlet
            </a>

            <a href="<?php echo e(route('paket.index')); ?>" class="menu-link <?php echo e(request()->routeIs('paket.*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-box"></i> Data Paket
            </a>
        <?php endif; ?>

        <div class="menu-title-main">LAINNYA</div>

        
        <?php if(auth()->user()->role == 'admin'): ?>
            <a href="<?php echo e(route('laporan.index')); ?>" 
                class="menu-link <?php echo e(request()->routeIs('laporan.*') ? 'active-menu' : ''); ?>">
                <i class="fa fa-file-text"></i> Laporan
            </a>
        <?php elseif(auth()->user()->role == 'kasir'): ?>
            <a href="<?php echo e(route('kasir.laporan')); ?>" 
                class="menu-link <?php echo e(request()->routeIs('kasir.laporan') ? 'active-menu' : ''); ?>">
                <i class="fa fa-file-text"></i> Laporan
            </a>
        <?php endif; ?>

    <?php endif; ?>

</div><?php /**PATH C:\laravel\BubbleBliss\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>