<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Beranda Kasir - BubbleBliss</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Hammersmith+One&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/kasir.css')); ?>">
</head>

<body>

    <!-- HEADER -->
    <div class="topbar">

        <div class="logo-header">

            <img src="<?php echo e(asset('images/logoputih.png')); ?>" width="45">

            <span style="font-size:26px">
                BubbleBliss
            </span>

        </div>

        <div class="header-right px-4">

            <div>

                <h4 class="mb-0" style="color:#0650d1; font-size:28px;">

                    BERANDA KASIR

                </h4>

                <small style="color:#5691f6; font-size:17px;">

                    Kelola Transaksi Laundry

                </small>

            </div>
    <?php echo $__env->make('partials.profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

        </div>

    </div>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- MAIN -->
    <div class="main">

        <div class="welcome-card">

            <h4 class="mb-1" style="color:#0650d1; font-size:28px;">

                Halo, <?php echo e(auth()->user()->name); ?>!

            </h4>

            <p class="mb-0" style="color:#5691f6">

                Selamat Datang Di Halaman Kasir
                <?php echo e(auth()->user()->outlet->nm_outlet ?? '-'); ?>


            </p>

        </div>

        <div class="row mb-4">

            <!-- KOLOM KIRI -->
            <div class="col-md-4">

                <!-- Pendapatan -->
                <div class="card-stat mb-3" style="background:#3577f3;">
                    <h6>Pendapatan Bulan Ini</h6>
                    <h2>
                        Rp <?php echo e(number_format($pendapatanBulanIni ?? 0, 0, ',', '.')); ?>

                    </h2>
                </div>

                <!-- Total Pesanan -->
                <div class="card-stat" style="background:#1a4fbf;">
                    <h6>Total Pesanan Bulan Ini</h6>
                    <h2>
                        <?php echo e($totalPesanan ?? 0); ?>

                    </h2>
                </div>

            </div>

            <!-- KOLOM KANAN -->
            <div class="col-md-8">

                <div class="bg-white rounded-4 shadow-sm p-4 h-100">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold text-dark mb-0">
                            Transaksi Terbaru
                        </h5>

                        <i class="fa fa-ellipsis-h text-secondary"></i>
                    </div>

                    <?php if($transaksiTerakhir->count()): ?>

                        <?php $__currentLoopData = $transaksiTerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="d-flex align-items-center justify-content-between py-2 border-bottom">

                                <div class="d-flex align-items-center gap-3">

                                    <div style="
                                                width:45px;
                                                height:45px;
                                                background:#f3f4f6;
                                                border-radius:10px;
                                                display:flex;
                                                align-items:center;
                                                justify-content:center;
                                            ">
                                        <i class="fa fa-shirt text-secondary"></i>
                                    </div>

                                    <div>

                                        <div class="fw-bold text-dark" style="font-family: Arial, Helvetica, sans-serif">
                                            <?php echo e($trx->pelanggan->nm_pelanggan ?? '-'); ?>

                                        </div>

                                        <small class="text-secondary" style="font-family: Arial, Helvetica, sans-serif">
                                            <?php echo e(\Carbon\Carbon::parse($trx->tgl_masuk)->format('d M Y')); ?>

                                        </small>

                                    </div>

                                </div>

                                <div class="text-end">

                                    <?php if($trx->status == 'selesai'): ?>

                                        <span class="badge bg-success rounded-pill px-3 py-2" style="text-white">
                                            Selesai
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-info rounded-pill px-3 py-2" style="text-white">
                                            Proses
                                        </span>

                                    <?php endif; ?>

                                    <div class="small text-secondary mt-1" style="font-family: Arial, Helvetica, sans-serif">
                                        <?php echo e($trx->kode_invoice); ?>

                                    </div>

                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>

                        <div class="text-center py-5 text-secondary">
                            Belum ada transaksi
                        </div>

                    <?php endif; ?>
<?php echo $__env->make('kasir.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH C:\laravel\BubbleBliss\resources\views/kasir/dashboard.blade.php ENDPATH**/ ?>